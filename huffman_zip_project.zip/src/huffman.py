import heapq
from collections import Counter

class Node:
    def __init__(self, char, freq):
        self.char = char
        self.freq = freq
        self.left = None
        self.right = None

    def __lt__(self, other):
        return self.freq < other.freq

def build_huffman_tree(frequency):
    heap = [Node(k, v) for k, v in frequency.items()]
    heapq.heapify(heap)

    while len(heap) > 1:
        l = heapq.heappop(heap)
        r = heapq.heappop(heap)
        merged = Node(None, l.freq + r.freq)
        merged.left = l
        merged.right = r
        heapq.heappush(heap, merged)

    return heap[0]

def generate_codes(node, prefix="", codebook={}):
    if node is None:
        return
    if node.char is not None:
        codebook[node.char] = prefix
    generate_codes(node.left, prefix + "0", codebook)
    generate_codes(node.right, prefix + "1", codebook)
    return codebook

def compress(input_bytes):
    frequency = Counter(input_bytes)
    tree = build_huffman_tree(frequency)
    codes = generate_codes(tree)

    encoded_bits = "".join(codes[b] for b in input_bytes)

    padding = 8 - len(encoded_bits) % 8
    encoded_bits += "0" * padding

    padded_info = f"{padding:08b}"
    byte_array = bytearray()
    full_bits = padded_info + encoded_bits

    for i in range(0, len(full_bits), 8):
        byte_array.append(int(full_bits[i:i + 8], 2))

    return byte_array, frequency

def decompress(data_bytes, frequency):
    padding = data_bytes[0]
    bit_string = ''.join(f"{b:08b}" for b in data_bytes[1:])
    bit_string = bit_string[:-padding]

    tree = build_huffman_tree(frequency)
    decoded = []
    node = tree

    for bit in bit_string:
        node = node.left if bit == "0" else node.right
        if node.char is not None:
            decoded.append(node.char)
            node = tree

    return bytes(decoded)
