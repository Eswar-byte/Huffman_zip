# Huffman Zip Project

A binary Huffman-based compressor and decompressor.
